import numpy as np
import pickle


def GE(A_origin, d=8, check=True):
    p, n = np.shape(A_origin)
    k = n - p
    A = np.copy(A_origin)
    empty_pivot = []
    # Step-1: transform the left p columns into an identity matrix through GE
    for pivot in range(p):
        # find the pivot
        found = False
        for col in range(pivot, n):  # scan all the columns from column-pivot
            if found:
                break
            for row in range(pivot, p):  # scan all the rows from row-pivot
                if A[row, col] == 1:
                    found = True
                    if not row == pivot:  # row swap
                        A[[pivot, row]] = A[[row, pivot]]
                    if not col == pivot:  # column swap, also swap the origin
                        A[:, [pivot, col]] = A[:, [col, pivot]]
                        A_origin[:, [pivot, col]] = A_origin[:, [col, pivot]]
                    break
        if found:  # XOR elimination
            for row in range(p):
                if (not row == pivot) and A[row][pivot] == 1:
                    A[row] = np.bitwise_xor(A[row], A[pivot])
        else:  # found an empty pivot
            empty_pivot.append(pivot)
    # Step-2: optional, double-check that we are correct
    if check:
        for pivot in range(p):
            if pivot in empty_pivot:
                assert np.sum(A[pivot, :p]) == 0
            else:
                # note that we cannot guarantee zeros in empty pivot locations
                assert np.sum(A[pivot, :p]) - \
                    np.sum(A[pivot, [empty_pivot]]) == 1
                assert A[pivot, pivot] == 1
    # Step-3: add linear independent rows for the empty pivots
    for pivot in empty_pivot:
        vec = np.zeros(n, dtype=bool)
        vec[pivot] = np.bool(1)
        indices = np.random.permutation(k)
        vec[indices[:d - 1] + p] = np.bool(1)
        A_origin = np.vstack([A_origin, vec])

    # Step-4: swap the left p columns to the right,
    # so that the right is full rank, which will adimit a systematic code.
    A_final = np.zeros(np.shape(A_origin))
    for col in range(n):
        A_final[:, col] = A_origin[:, (col + p) % n]
    return A_final, k


def matrix_to_list(A_final, k):
    # this function read the matrix and store:
    # parity_symbols: ps[i] lists the symbols involved in parity-i.
    # symbols_parity: sp[i] lists the parities symbol-i involves.
    p, n = np.shape(A_final)
    parity_symbols = []
    symbol_parities = []
    for row in range(p):
        parity_symbols.append(np.nonzero(A_final[row]))
    for col in range(n):
        symbol_parities.append(np.nonzero(A_final[:, col]))
    result = {}
    result['parities'] = parity_symbols
    result['symbols'] = symbol_parities
    with open('symbols_and_parities_k=' + str(k) + '.pickle', 'wb') as handle:
        pickle.dump(result, handle)
    print('saved', 'symbols_and_parities_k=' + str(k) + '.pickle')


def txt_to_matrix(file_name):
    # this function reads the txt description of the parity matrix
    # and realizes it.
    # row-i of the txt is the list of symbols involved in parity-i.
    raw = open(file_name, 'r').read()
    parties_lines = raw.splitlines()
    p = len(parties_lines)
    n = np.int(p * 4 / 3)
    A_origin = np.zeros((p, n), dtype=bool)
    for row in range(p):
        idx_list = parties_lines[row].split()
        A_origin[row, idx_list] = np.bool(1)
    return A_origin


def txt_to_sys_code(file_name):
    A_origin = txt_to_matrix(file_name)
    A_final, k = GE(A_origin, d=8)
    matrix_to_list(A_final, k)


txt_to_sys_code('newexample4.txt')
txt_to_sys_code('newexample16.txt')
txt_to_sys_code('newexample64.txt')
txt_to_sys_code('newexample256.txt')
